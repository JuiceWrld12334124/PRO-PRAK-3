<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/Framework.css">
    <link rel="stylesheet" href="/css/style.css">
    <title>Microhard</title>
</head>

<body>

<div class="navbar sticky">
        <div class="container flex">
            <h1 class="logo">Microhard</h1>
            <nav>
            <ul>
                </ul>
            </nav>
        </div>
    </div>
    <section class="overons-sub-head bg-light py-3">
    </section>
    <section class="review-head bg-primary">
        <p>We have recieved your ban appeal request, this process take approximately 2-3 work days. <a href="/api/logout.php" id="b-color" >Home</a></p>
    </section>


</body>

</html>